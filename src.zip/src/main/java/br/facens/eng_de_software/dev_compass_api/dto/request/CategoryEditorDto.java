package br.facens.eng_de_software.dev_compass_api.dto.request;

public record CategoryEditorDto(String name) {
}
