package br.facens.eng_de_software.dev_compass_api.model;

public enum JobListingState {
    UNPUBLISHED,
    PUBLISHED,
    SELECTION_IN_PROCESS,
    CLOSED;
}
