package br.facens.eng_de_software.dev_compass_api.security.repository;

import br.facens.eng_de_software.dev_compass_api.security.model.BaseUser;

public interface UserRepository extends GenericUserRepository<BaseUser> {
}
