package br.facens.eng_de_software.dev_compass_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevCompassApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevCompassApiApplication.class, args);
	}

}
