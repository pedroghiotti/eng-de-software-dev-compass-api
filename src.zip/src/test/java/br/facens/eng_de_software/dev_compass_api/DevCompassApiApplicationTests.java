package br.facens.eng_de_software.dev_compass_api;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import br.facens.eng_de_software.dev_compass_api.repository.CandidateRepository;
import br.facens.eng_de_software.dev_compass_api.repository.CategoryRepository;
import br.facens.eng_de_software.dev_compass_api.repository.JobListingRepository;
import br.facens.eng_de_software.dev_compass_api.repository.RegionRepository;
import br.facens.eng_de_software.dev_compass_api.repository.TechnologyRepository;
import br.facens.eng_de_software.dev_compass_api.security.repository.UserRepository;

@SpringBootTest
class DevCompassApiApplicationTests {

	@Autowired private UserRepository userRepository;
	@Autowired private JobListingRepository jobListingRepository;
	@Autowired private CandidateRepository candidateRepository;
	@Autowired private CategoryRepository categoryRepository;
	@Autowired private TechnologyRepository technologyRepository;
	@Autowired private RegionRepository regionRepository;

	@Test
	void contextLoads() {
	}

	
}
